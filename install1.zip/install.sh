echo "<h2>Hello World My Name is Shail, account id $2 </h2>" >> /var/www/html/hh.html

yum install mariadb-server -y
systemctl start mariadb

mysql -u root -e "create database mydb"
mysql -u root -e "use mydb; create table users ( id int, name nvarchar(30));"
mysql -u root -e "use mydb; insert into users values (1, 'kunal'); select * from users;"

cat <<EOF > /etc/sysconfig/network
NETWORKING=yes
NOZEROCONF=yes
HOSTNAME=mydbserver
EOF
hostnamectl set-hostname $1

mkdir -p /{mysql,mysqllog}

vgcreate vgmysql /dev/sdh
lvcreate -n lv_mysql -L 500M vgmysql
lvcreate -n lv_mysqllog -l 100%FREE vgmysql
mkfs -t ext4  /dev/vgmysql/lv_mysql
mkfs -t ext4  /dev/vgmysql/lv_mysqllog

[ ! -f /etc/fstab.orig ] && cp -p /etc/fstab /etc/fstab.orig
if [ `grep mysql /etc/fstab | wc -l` -eq 0 ]
then
cat <<EOF >> /etc/fstab
# DB Filesystems below
/dev/mapper/vgmysql-lv_mysql /mysql  ext4  defaults,nodev 1 2
/dev/mapper//vgmysql-lv_mysqllog /mysqllog  ext4  defaults,nodev 1 2
EOF
fi
mount -a
chown mysql.mysql /{mysql,mysqllog}



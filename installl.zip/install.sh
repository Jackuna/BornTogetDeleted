echo "<h2>Hello World My Name is Shail</h2>" >> /var/www/html/hh.html

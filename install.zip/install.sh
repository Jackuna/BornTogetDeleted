echo "Hello World My Name is Kunal" >> /var/www/html/kunal.html
